﻿define("epi-cms/content-approval/ApprovalService", [
    "dojo/_base/declare",
    "dojo/topic",
    "dojo/when",
    "dojo/Deferred",

    "epi/shell/xhr/errorHandler",
    "epi/dependency"
], function (
    declare,
    topic,
    when,
    Deferred,

    errorHandler,
    dependency
) {
    return declare(null,{
        // summary:
        //      A service for interacting with content approvals.
        // tags:
        //      internal

        // approvalStore: [readonly] Store
        //      A REST store for saving and loading approval.
        approvalStore: null,

        // approvalDefinitionStore: [readonly] Store
        //      A REST store for saving and loading approval definitions.
        approvalDefinitionStore: null,

        constructor: function (kwArgs, approvalStore, approvalDefinitionStore) {
            this.approvalStore = approvalStore || dependency.resolve("epi.storeregistry").get("epi.cms.approval");
            this.approvalDefinitionStore = approvalDefinitionStore || dependency.resolve("epi.storeregistry").get("epi.cms.approval.definition");
        },

        getApproval: function (contentLink) {
            // summary:
            //      Gets the approval for the given content link.
            // tags:
            //      public

            return when(this.approvalStore.get(contentLink)).otherwise(function () {
                // If the approval doesn't exist then return null.
                return null;
            });
        },

        approveChanges: function (approvalId, activeStepIndex, approveReason) {
            // summary: approves the changes for the given approval
            // tags:
            //      public

            return errorHandler.wrapXhr(this.approvalStore.executeMethod("ApproveChanges", approvalId, { activeStepIndex: activeStepIndex, approveReason: approveReason}));
        },

        forceCompleteApproval: function (approvalId, forceReason) {
            // summary:
            //      Force completes an approval instance as approved.
            // tags:
            //      public

            return errorHandler.wrapXhr(this.approvalStore.executeMethod("ForceComplete", approvalId, { forceReason: forceReason }));
        },

        rejectChanges: function (approvalId, activeStepIndex, rejectReason) {
            // summary: reject the changes for the given approval
            // tags:
            //      public

            return errorHandler.wrapXhr(this.approvalStore.executeMethod("RejectChanges", approvalId, { activeStepIndex: activeStepIndex, rejectReason: rejectReason }));
        },

        cancelChanges: function (approval) {
            // summary: cancel the changes for the given approval
            // tags:
            //      public

            return errorHandler.wrapXhr(this.approvalStore.executeMethod("CancelChanges", approval.id));
        },

        getDefinition: function (contentLink) {
            // summary:
            //      Gets the approval definition for the given content link.
            // tags:
            //      public

            return when(this.approvalDefinitionStore.get(contentLink)).otherwise(function () {
                // If the approval definition doesn't exist then return null.
                return null;
            });
        },

        getApprovalRelatedDefinition: function (contentLink) {
            // summary:
            //      Gets the approval definition which belongs to the currently running approval for given content link.
            // tags:
            //      public

            return when(this.approvalDefinitionStore.query({id: contentLink,  getApprovalRelatedDefinition: true })).otherwise(function () {
                // If the approval definition doesn't exist then return null.
                return null;
            });
        },

        navigateToDefinition: function (contentLink) {
            // summary:
            //      Navigate to the definition for the given content link
            // tags:
            //      public

            topic.publish("/epi/shell/context/request",
                { uri: "epi.cms.approval:///" + contentLink },
                { sender: null });
        },

        hasDefinition: function (contentLink) {
            // summary:
            //      Determines whether an approval definition has been created or inherited for the
            //      given content link.
            // tags:
            //      public

            return this.getDefinition(contentLink).then(function (definition) {
                // If a definition exists but has no id then it is the default empty definition.
                return definition !== null && definition.id !== 0;
            });
        },

        saveDefinition: function (definition) {
            // summary:
            //      Saves the approval definition.
            // tags:
            //      internal

            if (!definition) {
                return new Deferred().reject();
            }

            return errorHandler.wrapXhr(this.approvalDefinitionStore.put(definition));
        },

        deleteDefinition: function (contentLink) {
            // summary:
            //      Deletes the approval definition.
            // tags:
            //      internal

            return errorHandler.wrapXhr(this.approvalDefinitionStore.remove(contentLink));
        },

        inheritDefinition: function (contentLink) {
            // summary:
            //      Deletes the approval definition for given contentLink and returns its ancestor's definition.
            // returns: Promise
            //      A promise that resolves to the parent approval definition
            // tags:
            //      internal

            return errorHandler.wrapXhr(this.approvalDefinitionStore.executeMethod("Inherit", contentLink));
        }
    });
});
