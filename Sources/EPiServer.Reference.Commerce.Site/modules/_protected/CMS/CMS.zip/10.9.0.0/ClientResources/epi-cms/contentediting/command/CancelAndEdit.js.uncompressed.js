define("epi-cms/contentediting/command/CancelAndEdit", [
    "dojo/_base/declare",
    "dojo/_base/lang",

    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/contentediting/command/_ChangeContentStatus",

//Resources
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.toolbar.buttons.cancelandedit"
], function (
    declare,
    lang,

    ContentActionSupport,
    _ChangeContentStatus,

    resources
) {

    return declare([_ChangeContentStatus], {
        // summary:
        //      Cancel and edit content command. Available for any delayed published content, and puts the content to rejected when executed.
        //
        // tags:
        //      internal

        label: resources.label,

        tooltip: resources.title,

        iconClass: "epi-iconPen",

        action: ContentActionSupport.saveAction.CheckOut | ContentActionSupport.saveAction.ForceCurrentVersion,

        _execute: function () {
            // summary:
            //    Executes this command; publish the current content
            //
            // tags:
            //		protected

            return this.inherited(arguments).then(lang.hitch(this, function () {
                // Reset start publish date: if content hasn't been published yet, use Created date, otherwise use Published date.
                var contentData = this.model.contentData;
                this.model.setProperty("iversionable_startpublish", contentData.isPendingPublish ? contentData.created : contentData.lastPublished);
            }));
        }
    });
});
