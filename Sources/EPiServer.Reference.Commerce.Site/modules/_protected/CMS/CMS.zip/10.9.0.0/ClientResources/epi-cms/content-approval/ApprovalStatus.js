//>>built
define("epi-cms/content-approval/ApprovalStatus",{inReview:0,approved:1,rejected:2});