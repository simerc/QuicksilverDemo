define(
"dojo/cldr/nls/tr/buddhist", //begin v1.x content
{
	"dateFormatItem-yM": "MM.y G",
	"dateFormatItem-yQ": "Q y G",
	"dayPeriods-format-wide-pm": "ÖS",
	"dateFormatItem-MMMEd": "dd MMM E",
	"dateFormatItem-hms": "h:mm:ss a",
	"dateFormatItem-yQQQ": "QQQ y G",
	"days-standAlone-wide": [
		"Pazar",
		"Pazartesi",
		"Salı",
		"Çarşamba",
		"Perşembe",
		"Cuma",
		"Cumartesi"
	],
	"dateFormatItem-MMM": "LLL",
	"months-standAlone-narrow": [
		"O",
		"Ş",
		"M",
		"N",
		"M",
		"H",
		"T",
		"A",
		"E",
		"E",
		"K",
		"A"
	],
	"dateFormatItem-Gy": "y G",
	"dayPeriods-format-wide-am": "ÖÖ",
	"quarters-standAlone-abbr": [
		"Ç1",
		"Ç2",
		"Ç3",
		"Ç4"
	],
	"dateFormatItem-y": "y G",
	"dateFormatItem-yyyy": "y G",
	"months-standAlone-abbr": [
		"Oca",
		"Şub",
		"Mar",
		"Nis",
		"May",
		"Haz",
		"Tem",
		"Ağu",
		"Eyl",
		"Eki",
		"Kas",
		"Ara"
	],
	"dateFormatItem-Ed": "d E",
	"dateFormatItem-yMMM": "MMM y G",
	"days-standAlone-narrow": [
		"P",
		"P",
		"S",
		"Ç",
		"P",
		"C",
		"C"
	],
	"dateFormat-long": "dd MMMM y G",
	"dateFormatItem-Hm": "HH:mm",
	"dateFormatItem-yyMM": "MM.yy G",
	"dateFormat-medium": "dd MMM y G",
	"dateFormatItem-Hms": "HH:mm:ss",
	"dateFormatItem-yyMMM": "MMM yy G",
	"dateFormatItem-yyQQQQ": "QQQQ yy G",
	"dateFormatItem-yMd": "dd.MM.y G",
	"quarters-standAlone-wide": [
		"1. çeyrek",
		"2. çeyrek",
		"3. çeyrek",
		"4. çeyrek"
	],
	"dateFormatItem-yMMMM": "MMMM y G",
	"dateFormatItem-ms": "mm:ss",
	"quarters-standAlone-narrow": [
		"1.",
		"2.",
		"3.",
		"4."
	],
	"months-standAlone-wide": [
		"Ocak",
		"Şubat",
		"Mart",
		"Nisan",
		"Mayıs",
		"Haziran",
		"Temmuz",
		"Ağustos",
		"Eylül",
		"Ekim",
		"Kasım",
		"Aralık"
	],
	"dateFormatItem-MMMd": "dd MMM",
	"quarters-format-narrow": [
		"1.",
		"2.",
		"3.",
		"4."
	],
	"dateFormatItem-yyQ": "Q yy G",
	"months-format-abbr": [
		"Oca",
		"Şub",
		"Mar",
		"Nis",
		"May",
		"Haz",
		"Tem",
		"Ağu",
		"Eyl",
		"Eki",
		"Kas",
		"Ara"
	],
	"dateFormatItem-H": "HH",
	"quarters-format-abbr": [
		"Ç1",
		"Ç2",
		"Ç3",
		"Ç4"
	],
	"days-format-abbr": [
		"Paz",
		"Pzt",
		"Sal",
		"Çar",
		"Per",
		"Cum",
		"Cmt"
	],
	"dateFormatItem-mmss": "mm:ss",
	"dateFormatItem-M": "L",
	"days-format-narrow": [
		"P",
		"P",
		"S",
		"Ç",
		"P",
		"C",
		"C"
	],
	"dateFormatItem-yMMMd": "dd MMM y G",
	"dateFormatItem-MEd": "dd.MM E",
	"months-format-narrow": [
		"O",
		"Ş",
		"M",
		"N",
		"M",
		"H",
		"T",
		"A",
		"E",
		"E",
		"K",
		"A"
	],
	"days-standAlone-short": [
		"Pa",
		"Pt",
		"Sa",
		"Ça",
		"Pe",
		"Cu",
		"Ct"
	],
	"dateFormatItem-hm": "h:mm a",
	"days-standAlone-abbr": [
		"Paz",
		"Pzt",
		"Sal",
		"Çar",
		"Per",
		"Cum",
		"Cmt"
	],
	"dateFormat-short": "dd.MM.yyyy G",
	"dateFormatItem-yMMMEd": "dd MMM y G E",
	"dateFormat-full": "dd MMMM y G EEEE",
	"dateFormatItem-Md": "dd.MM",
	"dateFormatItem-yMEd": "dd.MM.y G E",
	"months-format-wide": [
		"Ocak",
		"Şubat",
		"Mart",
		"Nisan",
		"Mayıs",
		"Haziran",
		"Temmuz",
		"Ağustos",
		"Eylül",
		"Ekim",
		"Kasım",
		"Aralık"
	],
	"days-format-short": [
		"Pa",
		"Pt",
		"Sa",
		"Ça",
		"Pe",
		"Cu",
		"Ct"
	],
	"dateFormatItem-d": "d",
	"quarters-format-wide": [
		"1. çeyrek",
		"2. çeyrek",
		"3. çeyrek",
		"4. çeyrek"
	],
	"days-format-wide": [
		"Pazar",
		"Pazartesi",
		"Salı",
		"Çarşamba",
		"Perşembe",
		"Cuma",
		"Cumartesi"
	]
}
//end v1.x content
);